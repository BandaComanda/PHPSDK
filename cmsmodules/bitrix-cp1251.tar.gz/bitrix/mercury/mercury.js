window.Mercury = (function(){
    var widget      = {};

    var frameId;
    var frameWidth  = '715px';
    var frameHeight = '100%';
    var url         = 'http://widget.demo.mercurypos.ru';
    var token       = null;
    var rootElement = 'mercury';
    var origin      = window.location.origin;

    window.addEventListener('message', messageMercuryWidgetListener, false);

    function messageMercuryWidgetListener(e)
    {
        if (e.origin !== url) {
            return;
        }

        if (e.data.func === 'onClose') {
            var container = document.getElementById(rootElement);
            container.style.display = "none";
            if (widget.hasOwnProperty('onClose') && (typeof widget.onClose === 'function')) {
                widget.onClose(`mercury-${frameId}`);
            }
        }

        if (e.data.func === 'screenSize') {
            e.source.postMessage({ 'func': 'screenSize', 'data': getScreenSize() }, e.origin);
        }
    }

    function getScreenSize()
    {
        let width  = document.body.clientWidth;
        let height = document.body.clientHeight;

        return { width: width, height: height };
    }


    /**
     * Widget initialization.
     * @param {object} params Configuration options.
     */
    widget.init = function (params) {

        if (document.getElementById(`mercury-${frameId}`)) {
            var container = document.getElementById(rootElement);
            container.style.display = "block";
        } else {
            token = params.token;
            if (params.hasOwnProperty('onClose')) {
                widget.onClose = params.onClose;
            }
            var container = document.getElementById(rootElement);
            container.style.zIndex = "9999";
            container.style.position = "fixed";
            container.style.overflow = "hidden";
            container.style.top = "0";
            container.style.bottom = "0";
            container.style.right = "0";
            container.style.left = "0";
            container.style.height = "100vh";

            var overlay = document.createElement('div');
            overlay.style.background = "rgb(0, 0, 0) none repeat scroll 0% 0%";
            overlay.style.opacity = "0.7";
            overlay.style.position = "absolute";
            overlay.style.height = "100%";
            overlay.style.width = "100%";

            var loader = createLoader();
            var frame  = createFrame(loader);
            container.appendChild(overlay);
            container.appendChild(loader);
            container.appendChild(frame);
        }
    };


    /**
     * Returns IFRAME url.
     * @return {string}
     */
    function createFrameUrl() {
        return `${url}/?token=${token}&origin=${origin}`;
    }

    /**
     * Returns IFRAME element.
     * @return {Element}
     */
    function createFrame(loader) {
        var url   = createFrameUrl();
        var frame = document.createElement('iframe');
        frame.style.display = "none";
        frame.style.position = "absolute";
        frame.style.top      = "50%";
        frame.style.left     = "50%";
        frame.style.marginLeft = "-356px";
        frame.style.marginTop = "-262px";
        frameId   = createFrameId();

        frame.setAttribute('src', url);
        frame.setAttribute('width', frameWidth);
        frame.setAttribute('height', frameHeight);
        frame.frameBorder = 0;
        frame.scrolling = 'yes';
        frame.id = `mercury-${frameId}`;
        frame.addEventListener('load', function () {
            var container = document.getElementById(rootElement);
            container.removeChild(loader);
            frame.style.display = "block";
        });

        return frame;
    }


    /**
     * Creates loader
     */
    function createLoader() {
        var styleNode  = document.createElement('style');
        styleNode.type = "text/css";
        var styleText  = document.createTextNode('#mercury .loader{position:relative;width:75px;height:100px;top:50%;left:50%;margin-top:-50px;margin-left:-35px;}#mercury .loader__bar{position:absolute;bottom:0;width:10px;height:50%;background:#fff;-webkit-transform-origin:center bottom;transform-origin:center bottom;box-shadow:1px 1px 0 rgba(0,0,0,0.2)}#mercury .loader__bar:nth-child(1){left:0;-webkit-transform:scale(1,0.2);transform:scale(1,0.2);-webkit-animation:barUp1 4s infinite;animation:barUp1 4s infinite}#mercury .loader__bar:nth-child(2){left:15px;-webkit-transform:scale(1,0.4);transform:scale(1,0.4);-webkit-animation:barUp2 4s infinite;animation:barUp2 4s infinite}#mercury .loader__bar:nth-child(3){left:30px;-webkit-transform:scale(1,0.6);transform:scale(1,0.6);-webkit-animation:barUp3 4s infinite;animation:barUp3 4s infinite}#mercury .loader__bar:nth-child(4){left:45px;-webkit-transform:scale(1,0.8);transform:scale(1,0.8);-webkit-animation:barUp4 4s infinite;animation:barUp4 4s infinite}#mercury .loader__bar:nth-child(5){left:60px;-webkit-transform:scale(1,1);transform:scale(1,1);-webkit-animation:barUp5 4s infinite;animation:barUp5 4s infinite}#mercury .loader__ball{position:absolute;bottom:10px;left:0;width:10px;height:10px;background:#fff;border-radius:50%;-webkit-animation:ball 4s infinite;animation:ball 4s infinite}@-webkit-keyframes ball{0%{-webkit-transform:translate(0,0);transform:translate(0,0)}5%{-webkit-transform:translate(8px,-14px);transform:translate(8px,-14px)}10%{-webkit-transform:translate(15px,-10px);transform:translate(15px,-10px)}17%{-webkit-transform:translate(23px,-24px);transform:translate(23px,-24px)}20%{-webkit-transform:translate(30px,-20px);transform:translate(30px,-20px)}27%{-webkit-transform:translate(38px,-34px);transform:translate(38px,-34px)}30%{-webkit-transform:translate(45px,-30px);transform:translate(45px,-30px)}37%{-webkit-transform:translate(53px,-44px);transform:translate(53px,-44px)}40%{-webkit-transform:translate(60px,-40px);transform:translate(60px,-40px)}50%{-webkit-transform:translate(60px,0);transform:translate(60px,0)}57%{-webkit-transform:translate(53px,-14px);transform:translate(53px,-14px)}60%{-webkit-transform:translate(45px,-10px);transform:translate(45px,-10px)}67%{-webkit-transform:translate(37px,-24px);transform:translate(37px,-24px)}70%{-webkit-transform:translate(30px,-20px);transform:translate(30px,-20px)}77%{-webkit-transform:translate(22px,-34px);transform:translate(22px,-34px)}80%{-webkit-transform:translate(15px,-30px);transform:translate(15px,-30px)}87%{-webkit-transform:translate(7px,-44px);transform:translate(7px,-44px)}90%{-webkit-transform:translate(0,-40px);transform:translate(0,-40px)}100%{-webkit-transform:translate(0,0);transform:translate(0,0)}}@keyframes ball{0%{-webkit-transform:translate(0,0);transform:translate(0,0)}5%{-webkit-transform:translate(8px,-14px);transform:translate(8px,-14px)}10%{-webkit-transform:translate(15px,-10px);transform:translate(15px,-10px)}17%{-webkit-transform:translate(23px,-24px);transform:translate(23px,-24px)}20%{-webkit-transform:translate(30px,-20px);transform:translate(30px,-20px)}27%{-webkit-transform:translate(38px,-34px);transform:translate(38px,-34px)}30%{-webkit-transform:translate(45px,-30px);transform:translate(45px,-30px)}37%{-webkit-transform:translate(53px,-44px);transform:translate(53px,-44px)}40%{-webkit-transform:translate(60px,-40px);transform:translate(60px,-40px)}50%{-webkit-transform:translate(60px,0);transform:translate(60px,0)}57%{-webkit-transform:translate(53px,-14px);transform:translate(53px,-14px)}60%{-webkit-transform:translate(45px,-10px);transform:translate(45px,-10px)}67%{-webkit-transform:translate(37px,-24px);transform:translate(37px,-24px)}70%{-webkit-transform:translate(30px,-20px);transform:translate(30px,-20px)}77%{-webkit-transform:translate(22px,-34px);transform:translate(22px,-34px)}80%{-webkit-transform:translate(15px,-30px);transform:translate(15px,-30px)}87%{-webkit-transform:translate(7px,-44px);transform:translate(7px,-44px)}90%{-webkit-transform:translate(0,-40px);transform:translate(0,-40px)}100%{-webkit-transform:translate(0,0);transform:translate(0,0)}}@-webkit-keyframes barUp1{0%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}40%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}50%{-webkit-transform:scale(1,1);transform:scale(1,1)}90%{-webkit-transform:scale(1,1);transform:scale(1,1)}100%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}}@keyframes barUp1{0%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}40%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}50%{-webkit-transform:scale(1,1);transform:scale(1,1)}90%{-webkit-transform:scale(1,1);transform:scale(1,1)}100%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}}@-webkit-keyframes barUp2{0%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}40%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}50%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}90%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}100%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}}@keyframes barUp2{0%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}40%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}50%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}90%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}100%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}}@-webkit-keyframes barUp3{0%{-webkit-transform:scale(1,0.6);transform:scale(1,0.6)}100%{-webkit-transform:scale(1,0.6);transform:scale(1,0.6)}}@keyframes barUp3{0%{-webkit-transform:scale(1,0.6);transform:scale(1,0.6)}100%{-webkit-transform:scale(1,0.6);transform:scale(1,0.6)}}@-webkit-keyframes barUp4{0%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}40%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}50%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}90%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}100%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}}@keyframes barUp4{0%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}40%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}50%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}90%{-webkit-transform:scale(1,0.4);transform:scale(1,0.4)}100%{-webkit-transform:scale(1,0.8);transform:scale(1,0.8)}}@-webkit-keyframes barUp5{0%{-webkit-transform:scale(1,1);transform:scale(1,1)}40%{-webkit-transform:scale(1,1);transform:scale(1,1)}50%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}90%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}100%{-webkit-transform:scale(1,1);transform:scale(1,1)}}@keyframes barUp5{0%{-webkit-transform:scale(1,1);transform:scale(1,1)}40%{-webkit-transform:scale(1,1);transform:scale(1,1)}50%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}90%{-webkit-transform:scale(1,0.2);transform:scale(1,0.2)}100%{-webkit-transform:scale(1,1);transform:scale(1,1)}}');
        styleNode.appendChild(styleText);
        document.getElementsByTagName('head')[0].appendChild(styleNode);
        var loader = document.createElement('div');
        loader.setAttribute('class', 'loader');
        var loaderBar = document.createElement('div');
        loaderBar.setAttribute('class', 'loader__bar');
        var loaderBar1 = document.createElement('div');
        loaderBar1.setAttribute('class', 'loader__bar');
        var loaderBar2 = document.createElement('div');
        loaderBar2.setAttribute('class', 'loader__bar');
        var loaderBar3 = document.createElement('div');
        loaderBar3.setAttribute('class', 'loader__bar');
        var loaderBar4 = document.createElement('div');
        loaderBar4.setAttribute('class', 'loader__bar');

        var loaderBall = document.createElement('div');
        loaderBall.setAttribute('class', 'loader__ball');
        loader.appendChild(loaderBar);
        loader.appendChild(loaderBar1);
        loader.appendChild(loaderBar2);
        loader.appendChild(loaderBar3);
        loader.appendChild(loaderBar4);
        loader.appendChild(loaderBall);

        return loader;
    }


    /**
     * Returns random string.
     * @return {string}
     */
    function createFrameId() {
        return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    }


    return widget;

}());