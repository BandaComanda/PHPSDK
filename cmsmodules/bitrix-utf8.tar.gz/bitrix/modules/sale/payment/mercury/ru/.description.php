<?
global $MESS;

$MESS['SHOULD_PAY'] = 'Стоимость заказа до скидки';
$MESS['SHOULD_PAY_DESC'] = null;
$MESS['CURRENCY'] = 'Валюта';
$MESS['CURRENCY_DESC'] = null;
$MESS['STORE_CODE'] = 'Код магазина';
$MESS['STORE_CODE_DESC'] = 'Описание магазина';
$MESS['STORE_PRIVATE_KEY'] = 'Токен магазина';
$MESS['STORE_PRIVATE_KEY_DESC'] = 'Описание токена магазина';
$MESS['STORE_API_URL'] = 'Адрес URL платежной публичной страницы магазина';
$MESS['STORE_API_URL_DESC'] = 'Описание урла магазина';
$MESS['CORE_API_URL'] = 'Адрес API меркурия';
$MESS['CORE_API_URL_DESC'] = 'Описание <b>http://merchant.mercurypos.ru</b>';
$MESS['SALE_ORDER_ID'] = 'ID Заказа';
$MESS['SALE_DESC_ORDER_ID'] = 'Описание ордера';

$MESS['ADDRESS'] = 'Адрес доставки';
$MESS['ADDRESS_DESC'] = 'Необходимо заполнять адресом доставки';
$MESS['PHONE'] = 'Телефон покупателя';
$MESS['PHONE_DESC'] = 'Контактный номер покупателя';

